
const books = [
    {
        id: 1,
        title: "أرض زيكولا",
        author: "عمرو عبد الحميد",
        category: "روايات",
        description: "رواية خيالية تأخذ القارئ إلى عالم مختلف، حيث تصبح المعرفة والذكاء من أهم وسائل النجاة.",
        color: "#31515a"
    },
    {
        id: 2,
        title: "العادات الذرية",
        author: "جيمس كلير",
        category: "تطوير الذات",
        description: "كتاب يوضح كيف تساعد العادات الصغيرة على إحداث تغييرات إيجابية مستمرة.",
        color: "#8b6d45"
    },
    {
        id: 3,
        title: "موجز تاريخ العالم",
        author: "هـ. ج. ويلز",
        category: "تاريخ",
        description: "نظرة عامة على محطات مهمة في تاريخ البشرية والحضارات.",
        color: "#526b56"
    },
    {
        id: 4,
        title: "رحلة إلى الكون",
        author: "مجموعة مؤلفين",
        category: "علوم",
        description: "مدخل مبسط إلى الفضاء والكواكب والنجوم.",
        color: "#3b4e79"
    },
    {
        id: 5,
        title: "في قلبي أنثى عبرية",
        author: "خولة حمدي",
        category: "روايات",
        description: "رواية أدبية تتناول العلاقات الإنسانية والتحديات الاجتماعية.",
        color: "#865d65"
    },
    {
        id: 6,
        title: "قوة الآن",
        author: "إيكهارت تول",
        category: "تطوير الذات",
        description: "كتاب يناقش الوعي باللحظة الحالية والتعامل مع الأفكار.",
        color: "#777b59"
    },
    {
        id: 7,
        title: "قصة الحضارة",
        author: "ويل ديورانت",
        category: "تاريخ",
        description: "عرض لتاريخ الحضارات وتطور الثقافة والفكر عبر العصور.",
        color: "#9a7048"
    },
    {
        id: 8,
        title: "عالم الأحياء",
        author: "مجموعة مؤلفين",
        category: "علوم",
        description: "تعرف على الكائنات الحية وتنوعها وأسرار الحياة.",
        color: "#47756c"
    },
    {
        id: 9,
        title: "الأب الغني والأب الفقير",
        author: "روبرت كيوساكي",
        category: "تطوير الذات",
        description: "أفكار عن الثقافة المالية وطريقة التفكير في المال.",
        color: "#526078"
    },
    {
        id: 10,
        title: "رحلات جلفر",
        author: "جوناثان سويفت",
        category: "روايات",
        description: "رحلات خيالية إلى أماكن غريبة ومجتمعات مختلفة.",
        color: "#946b50"
    },
    {
        id: 11,
        title: "تاريخ مصر القديم",
        author: "مجموعة مؤلفين",
        category: "تاريخ",
        description: "نظرة تعريفية على الحضارة المصرية القديمة وأهم مراحلها.",
        color: "#967e45"
    },
    {
        id: 12,
        title: "الكون",
        author: "كارل ساغان",
        category: "علوم",
        description: "رحلة علمية لاستكشاف الكون ومكان الإنسان فيه.",
        color: "#39466d"
    }
];

function createBookCard(book) {
    return `
        <article class="book-card">
            <a href="book-details.html?id=${book.id}">
                <div class="book-cover" style="--cover:${book.color}">
                    <div class="book-cover-inner">
                        <span class="book-icon">📖</span>
                        <h3>${book.title}</h3>
                        <p>${book.author}</p>
                    </div>
                </div>
            </a>

            <div class="book-info">
                <span class="book-category">${book.category}</span>
                <h3 class="book-title">${book.title}</h3>
                <p class="book-author">تأليف: ${book.author}</p>
                <a class="btn btn-primary" href="book-details.html?id=${book.id}">
                    تفاصيل الكتاب
                </a>
            </div>
        </article>
    `;
}

// الكتب المميزة في الصفحة الرئيسية
const featured = document.getElementById("featured-books");

if (featured) {
    featured.innerHTML = books.slice(0, 3).map(createBookCard).join("");
}

// البحث والفلترة
const allBooks = document.getElementById("all-books");
const searchInput = document.getElementById("book-search");
const categoryFilter = document.getElementById("category-filter");
const emptyState = document.getElementById("empty-state");
const resultsCount = document.getElementById("results-count");

function renderBooks() {
    if (!allBooks) return;

    const query = (searchInput?.value || "").trim().toLocaleLowerCase();
    const category = categoryFilter?.value || "";

    const filtered = books.filter(book => {
        const searchable = (
            book.title + " " + book.author + " " + book.category
        ).toLocaleLowerCase();

        return searchable.includes(query) &&
            (!category || book.category === category);
    });

    allBooks.innerHTML = filtered.map(createBookCard).join("");

    if (emptyState) {
        emptyState.hidden = filtered.length > 0;
    }

    if (resultsCount) {
        resultsCount.textContent = `عدد الكتب المعروضة: ${filtered.length}`;
    }
}

if (allBooks) {
    const params = new URLSearchParams(window.location.search);
    const category = params.get("category");

    if (category && categoryFilter) {
        const validCategory = [...categoryFilter.options].some(
            option => option.value === category
        );

        if (validCategory) {
            categoryFilter.value = category;
        }
    }

    renderBooks();
}

searchInput?.addEventListener("input", renderBooks);
categoryFilter?.addEventListener("change", renderBooks);

// تفاصيل الكتاب
const detail = document.getElementById("book-detail");

if (detail) {
    const params = new URLSearchParams(window.location.search);
    const id = Number(params.get("id"));
    const book = books.find(item => item.id === id);

    if (book) {
        detail.innerHTML = `
            <div class="book-detail-cover"
                 style="background:linear-gradient(145deg, ${book.color}, #102838)">
                <div>
                    <div class="book-icon">📖</div>
                    <h2>${book.title}</h2>
                </div>
            </div>

            <div class="book-detail-content">
                <span class="book-category">${book.category}</span>
                <h1>${book.title}</h1>
                <h3>تأليف: ${book.author}</h3>
                <p>${book.description}</p>

                <div class="book-detail-meta">
                    <p><strong>التصنيف:</strong> ${book.category}</p>
                    <p><strong>المؤلف:</strong> ${book.author}</p>
                </div>

                <button class="btn btn-primary" id="borrow-button" type="button">
                    استعارة تجريبية
                </button>

                <p>هذا الزر تجريبي ولا ينشئ طلب استعارة فعليًا.</p>
                <a class="btn btn-outline" href="books.html">العودة إلى الكتب</a>
            </div>
        `;

        document.getElementById("borrow-button")?.addEventListener("click", () => {
            alert("هذه واجهة تجريبية فقط.");
        });
    } else {
        detail.innerHTML = `
            <div class="empty-state">
                <h2>الكتاب غير موجود</h2>
                <a class="btn btn-primary" href="books.html">العودة إلى الكتب</a>
            </div>
        `;
    }
}

// نموذج التواصل التجريبي
const contactForm = document.getElementById("contact-form");

contactForm?.addEventListener("submit", event => {
    event.preventDefault();

    const status = document.getElementById("form-status");

    if (status) {
        status.textContent =
            "تم التحقق من البيانات. النموذج لا يرسل رسائل فعلية.";
        status.className = "form-status success";
    }

    contactForm.reset();
});

// تسجيل الدخول التجريبي
const loginForm = document.getElementById("login-form");

loginForm?.addEventListener("submit", event => {
    event.preventDefault();

    const status = document.getElementById("login-status");

    if (status) {
        status.textContent =
            "الواجهة جاهزة، لكن تسجيل الدخول الفعلي يحتاج نظام حسابات.";
        status.className = "form-status";
    }
});

// إنشاء الحساب التجريبي
const registerForm = document.getElementById("register-form");

registerForm?.addEventListener("submit", event => {
    event.preventDefault();

    const password = document.getElementById("register-password")?.value || "";
    const confirmPassword = document.getElementById("confirm-password")?.value || "";
    const status = document.getElementById("register-status");

    if (!status) return;

    if (password !== confirmPassword) {
        status.textContent = "كلمتا المرور غير متطابقتين.";
        status.className = "form-status error";
        return;
    }

    status.textContent =
        "تم التحقق من البيانات. إنشاء الحساب الفعلي يحتاج نظام تسجيل.";
    status.className = "form-status success";
});

// السنة الحالية في الفوتر
document.querySelectorAll(".year").forEach(element => {
    element.textContent = new Date().getFullYear();
});
